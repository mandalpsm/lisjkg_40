# Academic Research Explorer (full-stack package)

| Part | Where | What it does |
|---|---|---|
| Front end | `public/index.html` | The complete app: search, Dashboard, Semantic Layer, Knowledge Graph, Research Intelligence, export. The dataset is embedded in the file. |
| Back end | `server/server.js` | Serves the app and proxies Neo4j and GraphDB so passwords never reach the browser. No npm packages needed. |

## Run
Requires Node.js 18 or newer.

- Windows: double-click `start.bat`
- Mac/Linux: `./start.sh`, or `npm start`
- Then open http://localhost:8000/

The app works fully without any database. Neo4j and GraphDB are optional.

## Connect Neo4j / GraphDB
1. Copy `.env.example` to `.env` and fill in your URLs and credentials.
2. Restart the server. Check http://localhost:8000/api/health to see which databases it can reach.
3. In the app open the Neo4j + GraphDB Integration Center, set **Mode** to *Backend proxy*, and leave the proxy endpoints as `http://localhost:8000/api/neo4j/query` and `http://localhost:8000/api/graphdb/query`. The password fields can stay empty.

### API
| Route | Body | Returns |
|---|---|---|
| `GET /api/health` | none | server status and whether each database is reachable |
| `POST /api/neo4j/query` | `{ "query": "MATCH ...", "parameters": {} }` | Neo4j Query API v2 JSON |
| `POST /api/graphdb/query` | `{ "query": "SELECT ..." }` | SPARQL JSON results |

By default `READ_ONLY=true` blocks Cypher and SPARQL statements that change data. Set `READ_ONLY=false` only on a trusted machine. The check is keyword-based, so it is a safety net, not a replacement for a read-only database user.

Note: "Push to GraphDB" in the Linked Open Data tab sends data straight from the browser to GraphDB and does not use this proxy.

## Publish on a server
- Set `HOST=0.0.0.0` and put the server behind HTTPS (for example nginx or Caddy). The server itself has no login, so restrict access if the databases hold private data.
- Docker: `docker build -t explorer .` then `docker run -p 8000:8000 --env-file .env explorer` (not tested in this package; from inside a container, point `NEO4J_URL` and `GRAPHDB_REPO_URL` at host addresses the container can reach).

## Changes in this version
- Dashboard: the "Other publishers" slice opens a clickable list of every smaller publisher.
- Knowledge Graph: numbered papers, halo labels, focus highlighting, type chips, papers list and key findings.
- Semantic Layer: Countries are counted per exact value (16).
