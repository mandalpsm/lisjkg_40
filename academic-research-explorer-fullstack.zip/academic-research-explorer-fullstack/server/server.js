'use strict';
/* Academic Research Explorer - zero-dependency Node server (Node 18+).
   Serves ./public and proxies Neo4j / GraphDB so credentials stay on the server. */
const http = require('http'), fs = require('fs'), path = require('path');
const ROOT = path.join(__dirname, '..');

try { // minimal .env loader
  fs.readFileSync(path.join(ROOT, '.env'), 'utf8').split(/\r?\n/).forEach(l => {
    const m = l.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/);
    if (m && !(m[1] in process.env)) process.env[m[1]] = m[2].replace(/^["']|["']$/g, '');
  });
} catch (e) { /* no .env: defaults apply */ }

const E = process.env;
const C = {
  port: +E.PORT || 8000,
  host: E.HOST || '127.0.0.1',
  readOnly: String(E.READ_ONLY || 'true').toLowerCase() !== 'false',
  neoUrl: (E.NEO4J_URL || 'http://localhost:7474').replace(/\/$/, ''),
  neoDb: E.NEO4J_DB || 'neo4j',
  neoUser: E.NEO4J_USER || '', neoPass: E.NEO4J_PASSWORD || '',
  gdRepo: (E.GRAPHDB_REPO_URL || 'http://localhost:7200/repositories/library').replace(/\/$/, ''),
  gdUser: E.GRAPHDB_USER || '', gdPass: E.GRAPHDB_PASSWORD || ''
};
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon', '.txt': 'text/plain; charset=utf-8' };
const WRITE_CYPHER = /\b(CREATE|MERGE|DELETE|DETACH|SET|REMOVE|DROP|FOREACH|LOAD\s+CSV)\b/i;
const WRITE_SPARQL = /\b(INSERT|DELETE|LOAD|CLEAR|DROP|CREATE|COPY|MOVE|ADD)\b/i;
const basic = (u, p) => (u ? { Authorization: 'Basic ' + Buffer.from(u + ':' + p).toString('base64') } : {});

const send = (res, code, body, type = 'application/json; charset=utf-8') => {
  res.writeHead(code, { 'Content-Type': type, 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' });
  res.end(typeof body === 'string' || Buffer.isBuffer(body) ? body : JSON.stringify(body));
};
const readJson = req => new Promise((ok, no) => {
  let n = 0; const chunks = [];
  req.on('data', c => { n += c.length; if (n > 1e6) { no(Object.assign(new Error('Request too large'), { code: 413 })); req.destroy(); } else chunks.push(c); });
  req.on('end', () => { try { ok(JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}')); } catch { no(Object.assign(new Error('Body must be JSON'), { code: 400 })); } });
  req.on('error', no);
});
async function relay(res, url, opt) {
  try {
    const r = await fetch(url, { ...opt, signal: AbortSignal.timeout(+E.UPSTREAM_TIMEOUT_MS || 30000) });
    send(res, r.status, await r.text());
  } catch (e) { send(res, 502, { error: 'Upstream unreachable: ' + (e.cause && e.cause.code || e.message) }); }
}
async function reachable(url, headers) {
  try { await fetch(url, { headers, signal: AbortSignal.timeout(2500) }); return true; } catch { return false; }
}

async function api(req, res, pathname) {
  if (pathname === '/api/health' && req.method === 'GET') {
    const [neo4j, graphdb] = await Promise.all([reachable(C.neoUrl), reachable(C.gdRepo + '/size', basic(C.gdUser, C.gdPass))]);
    return send(res, 200, { ok: true, readOnly: C.readOnly, neo4j: { url: C.neoUrl, reachable: neo4j }, graphdb: { url: C.gdRepo, reachable: graphdb } });
  }
  if (req.method !== 'POST') return send(res, 405, { error: 'Use POST' });
  let body; try { body = await readJson(req); } catch (e) { return send(res, e.code || 400, { error: e.message }); }
  const q = typeof body.query === 'string' ? body.query.trim() : '';
  if (!q) return send(res, 400, { error: 'Missing "query"' });
  if (pathname === '/api/neo4j/query') {
    if (C.readOnly && WRITE_CYPHER.test(q)) return send(res, 403, { error: 'Write queries are blocked (READ_ONLY=true)' });
    return relay(res, `${C.neoUrl}/db/${encodeURIComponent(C.neoDb)}/query/v2`, { method: 'POST',
      headers: { 'Content-Type': 'application/json', Accept: 'application/json', ...basic(C.neoUser, C.neoPass) },
      body: JSON.stringify({ statement: q, parameters: body.parameters && typeof body.parameters === 'object' ? body.parameters : {} }) });
  }
  if (pathname === '/api/graphdb/query') {
    if (C.readOnly && WRITE_SPARQL.test(q)) return send(res, 403, { error: 'SPARQL updates are blocked (READ_ONLY=true)' });
    return relay(res, C.gdRepo, { method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8', Accept: 'application/sparql-results+json', ...basic(C.gdUser, C.gdPass) },
      body: new URLSearchParams({ query: q }) });
  }
  send(res, 404, { error: 'Unknown API route' });
}

function serveStatic(req, res, pathname) {
  if (req.method !== 'GET' && req.method !== 'HEAD') return send(res, 405, 'Method not allowed', 'text/plain');
  let rel; try { rel = decodeURIComponent(pathname); } catch { return send(res, 400, 'Bad request', 'text/plain'); }
  if (rel.endsWith('/')) rel += 'index.html';
  const file = path.normalize(path.join(ROOT, 'public', rel));
  if (!file.startsWith(path.join(ROOT, 'public') + path.sep)) return send(res, 403, 'Forbidden', 'text/plain');
  fs.readFile(file, (err, data) => err ? send(res, 404, 'Not found', 'text/plain')
    : send(res, 200, req.method === 'HEAD' ? '' : data, MIME[path.extname(file).toLowerCase()] || 'application/octet-stream'));
}

http.createServer((req, res) => {
  const pathname = new URL(req.url, 'http://x').pathname;
  (pathname.startsWith('/api/') ? api(req, res, pathname) : Promise.resolve(serveStatic(req, res, pathname)))
    .catch(e => send(res, 500, { error: String(e.message || e) }));
}).listen(C.port, C.host, () => {
  console.log(`Academic Research Explorer  http://${C.host === '0.0.0.0' ? 'localhost' : C.host}:${C.port}/`);
  console.log(`Neo4j proxy:   POST /api/neo4j/query   -> ${C.neoUrl} (db ${C.neoDb})`);
  console.log(`GraphDB proxy: POST /api/graphdb/query -> ${C.gdRepo}`);
  console.log(`Read-only mode: ${C.readOnly ? 'ON' : 'OFF'}`);
});
