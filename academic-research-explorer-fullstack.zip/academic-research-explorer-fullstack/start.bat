@echo off
cd /d "%~dp0"
start "" http://localhost:8000/
node server\server.js
pause
